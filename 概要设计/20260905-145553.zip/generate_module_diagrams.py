#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
生成概要设计说明书中的模块结构图与时序图。

风格对齐 Visio 分层架构图：界面层（浅蓝）→ 业务子模块（浅橙）
→ 支撑与接口（深橙/黄）→ 服务端（灰），蓝色箭头表示调用方向。

用法（在本文件夹内执行，不依赖工程其它目录）：
    python generate_module_diagrams.py
    python generate_module_diagrams.py --out figures
"""

from __future__ import annotations

import argparse
import os
import sys
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Sequence, Tuple

import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle


# —— 与样图一致的配色 ——
C_UI = "#D6EAF8"
C_BIZ = "#FCE4D6"
C_SUP = "#ED7D31"
C_MODEL = "#FFD966"
C_SERVER = "#D9D9D9"
C_LABEL = "#C45911"
C_ARROW = "#2E75B6"
C_TITLE = "#1F4E79"
C_TEXT = "#1F1F1F"
C_EDGE = "#7F7F7F"
C_LIFE = "#9DC3E6"
C_ACTOR = "#D6EAF8"


def _pick_font() -> str:
    candidates = [
        "Microsoft YaHei",
        "Microsoft YaHei UI",
        "SimHei",
        "Noto Sans CJK SC",
        "Noto Sans CJK JP",
        "Source Han Sans SC",
        "WenQuanYi Micro Hei",
        "PingFang SC",
        "STHeiti",
        "Arial Unicode MS",
    ]
    available = {f.name for f in font_manager.fontManager.ttflist}
    for name in candidates:
        if name in available:
            return name
    # 部分环境字体名带后缀
    for f in font_manager.fontManager.ttflist:
        lower = f.name.lower()
        if "yahei" in lower or "simhei" in lower or "cjk" in lower or "noto sans" in lower:
            return f.name
    return "DejaVu Sans"


FONT = _pick_font()
plt.rcParams["font.family"] = FONT
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["pdf.fonttype"] = 42


@dataclass
class Box:
    box_id: str
    title: str
    subtitle: str = ""
    color: str = C_BIZ
    x: float = 0.0
    y: float = 0.0
    w: float = 1.0
    h: float = 1.0
    title_size: float = 11.5
    sub_size: float = 8.6


@dataclass
class Arrow:
    src: str
    dst: str
    bidir: bool = False
    label: str = ""
    rad: float = 0.0


@dataclass
class Layer:
    name: str
    boxes: List[Box] = field(default_factory=list)


def _round_box(ax, box: Box, z: int = 3) -> None:
    patch = FancyBboxPatch(
        (box.x, box.y),
        box.w,
        box.h,
        boxstyle="round,pad=0.012,rounding_size=0.10",
        linewidth=1.15,
        edgecolor=C_EDGE,
        facecolor=box.color,
        mutation_aspect=0.6,
        zorder=z,
    )
    ax.add_patch(patch)
    cx = box.x + box.w / 2
    if box.subtitle:
        ax.text(
            cx,
            box.y + box.h * 0.66,
            box.title,
            ha="center",
            va="center",
            fontsize=box.title_size,
            fontweight="bold",
            color=C_TEXT,
            zorder=z + 1,
        )
        ax.text(
            cx,
            box.y + box.h * 0.32,
            box.subtitle,
            ha="center",
            va="center",
            fontsize=box.sub_size,
            color="#333333",
            linespacing=1.35,
            zorder=z + 1,
        )
    else:
        ax.text(
            cx,
            box.y + box.h / 2,
            box.title,
            ha="center",
            va="center",
            fontsize=box.title_size,
            fontweight="bold",
            color=C_TEXT,
            zorder=z + 1,
        )


def _anchor(box: Box, side: str) -> Tuple[float, float]:
    cx = box.x + box.w / 2
    cy = box.y + box.h / 2
    if side == "n":
        return cx, box.y + box.h
    if side == "s":
        return cx, box.y
    if side == "e":
        return box.x + box.w, cy
    if side == "w":
        return box.x, cy
    return cx, cy


def _choose_sides(a: Box, b: Box) -> Tuple[str, str]:
    a_top, a_bot = a.y + a.h, a.y
    b_top, b_bot = b.y + b.h, b.y
    y_overlap = not (a_bot > b_top - 0.02 or b_bot > a_top - 0.02)
    if not y_overlap:
        # 不同层之间一律上下连接，避免斜向误连到邻框。
        return ("n", "s") if (b.y + b.h / 2) > (a.y + a.h / 2) else ("s", "n")
    return ("e", "w") if (b.x + b.w / 2) > (a.x + a.w / 2) else ("w", "e")


def _draw_arrow(ax, a: Box, b: Box, spec: Arrow) -> None:
    s1, s2 = _choose_sides(a, b)
    x1, y1 = _anchor(a, s1)
    x2, y2 = _anchor(b, s2)
    style = "<|-|>" if spec.bidir else "-|>"
    conn = f"arc3,rad={spec.rad}" if spec.rad else "arc3,rad=0"
    patch = FancyArrowPatch(
        (x1, y1),
        (x2, y2),
        arrowstyle=style,
        mutation_scale=12,
        linewidth=1.35,
        color=C_ARROW,
        connectionstyle=conn,
        zorder=5,
        shrinkA=1.5,
        shrinkB=1.5,
    )
    ax.add_patch(patch)
    if spec.label:
        mx, my = (x1 + x2) / 2, (y1 + y2) / 2
        if s1 in ("e", "w") and s2 in ("e", "w"):
            my += 0.12 + spec.rad * 0.25
        else:
            mx += 0.10 + spec.rad * 0.8
            my += 0.04
        ax.text(
            mx,
            my,
            spec.label,
            ha="center",
            va="bottom",
            fontsize=7.8,
            color=C_ARROW,
            fontweight="bold",
            zorder=6,
            linespacing=1.15,
        )


def draw_architecture(
    title: str,
    layers: Sequence[Layer],
    arrows: Sequence[Arrow],
    outfile: str,
    figsize: Tuple[float, float] = (13.4, 8.6),
    caption: str = "",
) -> None:
    all_boxes = [b for layer in layers for b in layer.boxes]
    # FancyBbox 的 pad 会超出给定矩形，按视觉外沿留白。
    max_top = max(b.y + b.h for b in all_boxes) + 0.16
    title_band = 0.85
    ylim_top = max_top + title_band
    data_w = 13.2
    fig_w = figsize[0]
    fig_h = max(figsize[1], fig_w * ylim_top / data_w + 0.55)

    fig, ax = plt.subplots(figsize=(fig_w, fig_h), dpi=160)
    fig.patch.set_facecolor("white")
    ax.set_xlim(0, data_w)
    ax.set_ylim(0, ylim_top)
    ax.set_aspect("equal")
    ax.axis("off")

    index: Dict[str, Box] = {}
    for layer in layers:
        if layer.name:
            ys = [b.y for b in layer.boxes]
            hs = [b.h for b in layer.boxes]
            mid = (min(ys) + max(y + h for y, h in zip(ys, hs))) / 2
            ax.text(
                0.22,
                mid,
                layer.name,
                ha="left",
                va="center",
                fontsize=11,
                fontweight="bold",
                color=C_LABEL,
                rotation=0,
            )
        for box in layer.boxes:
            _round_box(ax, box)
            index[box.box_id] = box

    for spec in arrows:
        _draw_arrow(ax, index[spec.src], index[spec.dst], spec)

    if caption:
        ax.text(6.6, 0.22, caption, ha="center", va="center",
                fontsize=8.5, color="#666666")

    # 标题最后画，放在所有模块框上方，避免被圆角框盖住。
    ax.text(
        6.6,
        max_top + 0.42,
        title,
        ha="center",
        va="center",
        fontsize=16,
        fontweight="bold",
        color=C_TITLE,
        zorder=20,
        clip_on=False,
    )

    fig.subplots_adjust(left=0.03, right=0.99, top=0.97, bottom=0.04)
    os.makedirs(os.path.dirname(outfile) or ".", exist_ok=True)
    fig.savefig(outfile, bbox_inches="tight", pad_inches=0.28, facecolor="white")
    plt.close(fig)


def draw_sequence(
    title: str,
    actors: Sequence[str],
    messages: Sequence[Tuple],
    outfile: str,
    note: str = "",
) -> None:
    """
    messages 元素：
        (from_idx, to_idx, text)
        (from_idx, to_idx, text, "reply")   虚线返回
        (from_idx, from_idx, text, "self")  自调用
    """
    n = len(actors)
    rows = len(messages)
    width = max(11.5, 2.35 * n + 1.4)
    height = max(5.8, 1.55 + 0.52 * rows + (0.45 if note else 0))
    fig, ax = plt.subplots(figsize=(width, height), dpi=160)
    fig.patch.set_facecolor("white")
    ax.set_xlim(0, width)
    ax.set_ylim(0, height)
    ax.axis("off")

    ax.text(width / 2, height - 0.32, title, ha="center", va="center",
            fontsize=14.5, fontweight="bold", color=C_TITLE)

    xs = [1.15 + i * (width - 1.6) / max(n - 1, 1) for i in range(n)]
    head_y = height - 0.95
    life_top = head_y - 0.42
    life_bot = 0.55 if note else 0.35

    for i, name in enumerate(actors):
        bw, bh = 1.85, 0.62
        box = FancyBboxPatch(
            (xs[i] - bw / 2, head_y - bh / 2),
            bw,
            bh,
            boxstyle="round,pad=0.01,rounding_size=0.08",
            linewidth=1.1,
            edgecolor=C_EDGE,
            facecolor=C_ACTOR,
            zorder=4,
        )
        ax.add_patch(box)
        ax.text(xs[i], head_y, name, ha="center", va="center",
                fontsize=9.2, fontweight="bold", color=C_TEXT, zorder=5)
        ax.plot([xs[i], xs[i]], [life_top, life_bot], color=C_LIFE,
                linewidth=1.1, linestyle=(0, (2.5, 2.2)), zorder=1)
        ax.add_patch(Rectangle((xs[i] - 0.045, life_bot), 0.09,
                               life_top - life_bot, facecolor="#F2F8FC",
                               edgecolor="none", zorder=0))

    y = head_y - 0.95
    for msg in messages:
        src, dst, text = msg[0], msg[1], msg[2]
        kind = msg[3] if len(msg) > 3 else "call"
        x1, x2 = xs[src], xs[dst]
        if kind == "self":
            ax.annotate(
                "",
                xy=(x1 + 0.02, y - 0.22),
                xytext=(x1 + 0.02, y),
                arrowprops=dict(arrowstyle="-|>", color=C_ARROW, lw=1.2,
                                connectionstyle="bar,fraction=-0.35"),
            )
            ax.text(x1 + 0.22, y - 0.08, text, ha="left", va="center",
                    fontsize=8.2, color=C_TEXT)
            y -= 0.58
            continue
        style = "->" if kind != "reply" else "->"
        ls = (0, (3, 2)) if kind == "reply" else "solid"
        ax.annotate(
            "",
            xy=(x2, y),
            xytext=(x1, y),
            arrowprops=dict(arrowstyle=style, color=C_ARROW, lw=1.25,
                            linestyle=ls),
        )
        mx = (x1 + x2) / 2
        ax.text(mx, y + 0.08, text, ha="center", va="bottom",
                fontsize=8.2, color=C_TEXT)
        y -= 0.52

    if note:
        ax.text(width / 2, 0.22, note, ha="center", va="center",
                fontsize=8.2, color="#666666")

    fig.tight_layout(pad=0.3)
    os.makedirs(os.path.dirname(outfile) or ".", exist_ok=True)
    fig.savefig(outfile, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def _box(box_id, title, subtitle, color, x, y, w, h, ts=11.2, ss=8.4) -> Box:
    return Box(box_id, title, subtitle, color, x, y, w, h, ts, ss)


def draw_pipeline(
    title: str,
    col_headers: Sequence[str],
    flows: Sequence[dict],
    outfile: str,
    caption: str = "",
) -> None:
    """
    从左到右画一条或多条代码链路。
    每个 flow:
      name  — 左侧流程名
      cells — 与列头等长，每格 (标题, 说明)
      data  — 相邻列之间的数据/动作标签
    """
    n_row = len(flows)
    name_w = 1.22
    left = 1.42
    col_w = 2.28
    gap_x = 0.20
    box_h = 1.26
    row_gap = 0.64
    top = 0.62 + n_row * (box_h + row_gap)
    fig_w = 14.6
    fig_h = max(8.6, top + 1.45)

    fig, ax = plt.subplots(figsize=(fig_w, fig_h), dpi=160)
    fig.patch.set_facecolor("white")
    ax.set_xlim(0, 14.4)
    ax.set_ylim(0, fig_h)
    ax.set_aspect("equal")
    ax.axis("off")

    ax.text(7.2, fig_h - 0.36, title, ha="center", va="center",
            fontsize=15.2, fontweight="bold", color=C_TITLE, zorder=20, clip_on=False)

    header_y = top + 0.10
    colors = [C_UI, C_SUP, C_BIZ, C_SERVER, C_MODEL]
    ax.text(0.08 + name_w / 2, header_y, "代码路径", ha="center", va="bottom",
            fontsize=9.0, fontweight="bold", color=C_LABEL)
    for i, header in enumerate(col_headers):
        cx = left + i * (col_w + gap_x) + col_w / 2
        ax.text(cx, header_y, header, ha="center", va="bottom",
                fontsize=9.2, fontweight="bold", color=C_LABEL)

    def _wrap_lab(text: str) -> str:
        if not text or len(text) <= 9:
            return text
        for sep in (" / ", " · ", "+", "|"):
            if sep in text:
                return text.replace(sep, "\n", 1)
        return text[:8] + "\n" + text[8:]

    for r, flow in enumerate(flows):
        y = top - (r + 1) * (box_h + row_gap) + row_gap
        name_box = Box(f"{r}_name", flow["name"], "", C_BIZ, 0.08, y, name_w, box_h, 8.6, 7.2)
        _round_box(ax, name_box)
        boxes: List[Box] = []
        for i, cell in enumerate(flow["cells"]):
            ct, cs = cell if isinstance(cell, tuple) else (cell, "")
            b = Box(
                f"{r}_{i}", ct, cs, colors[i % len(colors)],
                left + i * (col_w + gap_x), y, col_w, box_h, 9.1, 7.3,
            )
            _round_box(ax, b)
            boxes.append(b)
        labels = flow.get("data", [])
        for i, lab in enumerate(labels):
            if i + 1 >= len(boxes):
                break
            a, b = boxes[i], boxes[i + 1]
            x1, y1 = _anchor(a, "e")
            x2, y2 = _anchor(b, "w")
            ax.annotate(
                "",
                xy=(x2, y2),
                xytext=(x1, y1),
                arrowprops=dict(arrowstyle="-|>", color=C_ARROW, lw=1.25),
            )
            ax.text(
                (x1 + x2) / 2,
                y1 + 0.16,
                _wrap_lab(lab),
                ha="center",
                va="bottom",
                fontsize=6.9,
                color=C_ARROW,
                fontweight="bold",
                linespacing=1.15,
            )

    if caption:
        ax.text(7.0, 0.22, caption, ha="center", va="center",
                fontsize=8.3, color="#666666")

    fig.subplots_adjust(left=0.02, right=0.99, top=0.97, bottom=0.04)
    os.makedirs(os.path.dirname(outfile) or ".", exist_ok=True)
    fig.savefig(outfile, bbox_inches="tight", pad_inches=0.28, facecolor="white")
    plt.close(fig)


def build_system(out: str) -> None:
    layers = [
        Layer("表现层", [
            _box("uc", "user_client", "车主 UI\nServerApiClient 出站", C_UI, 1.7, 4.85, 4.5, 1.28, 11.2, 8.2),
            _box("ac", "admin_client", "运营 UI\nAdminApiClient 出站", C_UI, 7.0, 4.85, 4.5, 1.28, 11.2, 8.2),
        ]),
        Layer("服务层", [
            _box("srv", "admin_server", "唯一业务入口  ·  TCP :9000\n接收帧 JSON，完成校验与编排", C_SUP, 3.1, 2.85, 7.0, 1.22, 11.0, 8.1),
        ]),
        Layer("数据层", [
            _box("db", "SQLite", "站点 / 电桩 / 用户 / 订单等持久化\n仅服务层访问", C_MODEL, 3.1, 1.15, 7.0, 1.12, 11.0, 8.1),
        ]),
    ]
    arrows = [
        Arrow("uc", "srv", bidir=True, label="TCP/JSON"),
        Arrow("ac", "srv", bidir=True, label="TCP/JSON"),
        Arrow("srv", "db", bidir=True, label="SQL"),
    ]
    draw_architecture(
        "图 2-1  系统结构图",
        layers, arrows, out, figsize=(13.2, 7.8),
        caption="表现层不直连数据库。两端前端只发请求，业务校验与库访问集中在服务层。",
    )


def build_user_client_overall(out: str) -> None:
    layers = [
        Layer("界面层", [
            _box("login", "LoginDialog", "登录 / 注册", C_UI, 1.55, 5.15, 3.15, 1.15),
            _box("main", "MainWindow", "底栏：充电站 / 充电 / 我的", C_UI, 5.15, 5.15, 7.35, 1.15),
        ]),
        Layer("业务子模块", [
            _box("acct", "账号管理与登录", "登录 · 注册 · 会话\n登出", C_BIZ, 1.45, 3.15, 3.35, 1.28),
            _box("svc", "用户服务", "定位 · 找站 · 导航 · 选桩\n预约 · 充电 · 个人中心", C_BIZ, 5.05, 3.15, 4.15, 1.28),
            _box("pay", "支付业务", "钱包充值\n充电记录", C_BIZ, 9.45, 3.15, 3.05, 1.28),
        ]),
        Layer("支撑与接口", [
            _box("loc", "LocationProvider", "定位辅助", C_SUP, 1.55, 1.25, 3.15, 1.12),
            _box("api", "ServerApiClient", "TCP API 接口", C_SUP, 5.25, 1.25, 3.75, 1.12),
            _box("model", "Models / FramedJson", "数据模型与帧编解码", C_MODEL, 9.35, 1.25, 3.15, 1.12),
        ]),
    ]
    arrows = [
        Arrow("login", "acct", label="手机号+密码"),
        Arrow("main", "svc", label="位置/选站/选桩"),
        Arrow("main", "pay", label="金额/查单"),
        Arrow("acct", "api", label="token"),
        Arrow("svc", "loc", label="经纬度"),
        Arrow("svc", "api", label="站/桩/预约/充电"),
        Arrow("pay", "api", label="充值/订单"),
        Arrow("api", "model", label="编解码"),
    ]
    draw_architecture("图 3-1  user_client 模块结构图", layers, arrows, out,
                      figsize=(13.4, 8.2),
                      caption="三个业务子模块互不调用。定位只服务找站；出站统一走 ServerApiClient。")


def build_user_account(out: str) -> None:
    layers = [
        Layer("界面", [
            _box("a", "登录页", "手机号 + 密码", C_UI, 1.6, 5.55, 3.1, 1.05),
            _box("b", "注册页", "手机号 + 密码 + 昵称", C_UI, 5.15, 5.55, 3.3, 1.05),
            _box("c", "登出入口", "MainWindow 侧/个人中心", C_UI, 8.85, 5.55, 3.15, 1.05),
        ]),
        Layer("窗体", [
            _box("dlg", "LoginDialog", "QStackedWidget 承载登录/注册", C_UI, 3.55, 3.85, 6.3, 1.05),
        ]),
        Layer("接口", [
            _box("api", "ServerApiClient", "phoneLogin / registerUser / logout", C_SUP, 3.55, 2.15, 6.3, 1.05),
        ]),
    ]
    arrows = [
        Arrow("a", "dlg"),
        Arrow("b", "dlg"),
        Arrow("c", "api"),
        Arrow("dlg", "api"),
    ]
    draw_architecture("图 3-1-1a  账号管理与登录子模块", layers, arrows, out,
                      figsize=(13.0, 7.4))


def build_user_service(out: str) -> None:
    layers = [
        Layer("界面功能", [
            _box("s1", "附近电站", "列表 / 筛选 / 距离", C_UI, 1.45, 6.55, 2.7, 1.0, 10.5, 8.0),
            _box("s2", "电站导航", "外部地图坐标", C_UI, 4.35, 6.55, 2.5, 1.0, 10.5, 8.0),
            _box("s3", "电桩预约收藏", "筛选 · 15 分钟锁桩", C_UI, 7.05, 6.55, 2.7, 1.0, 10.5, 8.0),
            _box("s4", "充电 / 个人中心", "进度 · 资料 · 余额", C_UI, 9.95, 6.55, 2.7, 1.0, 10.5, 8.0),
        ]),
        Layer("内部功能", [
            _box("locf", "定位服务", "GeoClue → IP 兜底", C_BIZ, 1.7, 4.7, 4.7, 1.1),
            _box("rec", "断线重连 / 会话恢复", "恢复预约与进行中订单", C_BIZ, 7.0, 4.7, 5.35, 1.1),
        ]),
        Layer("支撑", [
            _box("lp", "LocationProvider", "定位实现", C_SUP, 1.7, 2.85, 4.7, 1.0),
            _box("api", "ServerApiClient", "stations / piles / reservation / charge / user", C_SUP, 7.0, 2.85, 5.35, 1.0, 10.5, 8.0),
        ]),
    ]
    arrows = [
        Arrow("s1", "locf"),
        Arrow("s2", "api"),
        Arrow("s3", "api"),
        Arrow("s4", "api"),
        Arrow("s4", "rec"),
        Arrow("locf", "lp"),
        Arrow("rec", "api"),
        Arrow("s1", "api"),
    ]
    draw_architecture("图 3-1-1b  用户服务子模块", layers, arrows, out,
                      figsize=(13.4, 8.4))


def build_user_pay(out: str) -> None:
    layers = [
        Layer("界面", [
            _box("w", "钱包充值页", "自定义金额 + 快捷面额", C_UI, 1.8, 4.9, 4.7, 1.15),
            _box("o", "充电记录页", "订单号 / 站点 / 电量 / 金额 / 状态", C_UI, 7.05, 4.9, 4.9, 1.15),
        ]),
        Layer("接口", [
            _box("api", "ServerApiClient", "wallet.recharge  /  orders.list", C_SUP, 3.55, 2.7, 6.5, 1.1),
        ]),
    ]
    arrows = [Arrow("w", "api"), Arrow("o", "api")]
    draw_architecture("图 3-1-1c  支付业务子模块", layers, arrows, out,
                      figsize=(13.0, 6.8))


def build_admin_overall(out: str) -> None:
    layers = [
        Layer("界面层", [
            _box("login", "LoginDialog", "登录 / 注册窗体", C_UI, 1.5, 5.15, 3.2, 1.12),
            _box("main", "MainWindow",
                 "侧栏业务页 + 当前管理员\n夜间模式 · 退出登录",
                 C_UI, 5.05, 5.15, 7.5, 1.12, 11.0, 8.1),
        ]),
        Layer("业务子模块", [
            _box("acct", "账号管理与登录", "登录/登出 · 注册界面\n创建邀请码", C_BIZ, 1.35, 3.15, 2.7, 1.32, 10.2, 7.9),
            _box("ops", "运营监控", "电桩/电站/预约\n后台重启 · 用户", C_BIZ, 4.25, 3.15, 2.7, 1.32, 10.2, 7.9),
            _box("fin", "财务管理", "今日/本月/总营收\n7/30 日折线 · 近单", C_BIZ, 7.15, 3.15, 2.7, 1.32, 10.2, 7.9),
            _box("ui", "界面美化", "白天/夜间模式\n全页图表表格换色", C_BIZ, 10.05, 3.15, 2.7, 1.32, 10.2, 7.9),
        ]),
        Layer("支撑与接口", [
            _box("api", "AdminApiClient", "TCP 出站 · token · NEED_FORCE", C_SUP, 1.5, 1.25, 4.55, 1.1, 10.6, 8.1),
            _box("style", "StyleHelper", "浅色 / 深色样式表", C_MODEL, 6.3, 1.25, 2.85, 1.1, 10.6, 8.1),
            _box("model", "Models / FramedJson", "结构体与帧协议", C_MODEL, 9.4, 1.25, 3.25, 1.1, 10.6, 8.1),
        ]),
    ]
    arrows = [
        Arrow("login", "acct", label="账号密码 / 邀请码"),
        Arrow("main", "acct", label="退出 / 发码"),
        Arrow("main", "ops", label="筛选条件 / ID"),
        Arrow("main", "fin", label="days=7|30"),
        Arrow("main", "ui", label="darkMode"),
        Arrow("acct", "api", label="要 token"),
        Arrow("ops", "api", label="桩/站/用户/预约"),
        Arrow("fin", "api", label="dashboard"),
        Arrow("ui", "style", label="换 QSS"),
        Arrow("api", "model", label="编解码"),
    ]
    draw_architecture(
        "图 3-2  admin_client 模块结构图",
        layers, arrows, out, figsize=(13.4, 8.4),
        caption="四个业务模块互不调用。账号/运营/财务统一经 AdminApiClient 出站；界面美化只走 StyleHelper。",
    )


def build_admin_account(out: str) -> None:
    layers = [
        Layer("界面", [
            _box("login", "登录页", "账号 + 密码\n空则本地拦截", C_UI, 1.35, 5.25, 2.55, 1.18, 10.4, 7.8),
            _box("reg", "注册页", "账号/密码/姓名\n+ 邀请码", C_UI, 4.05, 5.25, 2.55, 1.18, 10.4, 7.8),
            _box("out", "侧栏退出", "确认后回登录窗", C_UI, 6.75, 5.25, 2.45, 1.18, 10.4, 7.8),
            _box("perm", "权限页发码", "选 operator\n/ auditor", C_UI, 9.35, 5.25, 2.5, 1.18, 10.3, 7.7),
        ]),
        Layer("会话数据", [
            _box("sess", "m_token + Admin", "登录/注册写入\n侧栏读姓名/角色", C_MODEL, 2.15, 3.35, 4.15, 1.22, 10.8, 8.0),
            _box("code", "邀请码 code", "发码得到明文\n注册时一次性消耗", C_MODEL, 7.15, 3.35, 4.15, 1.22, 10.8, 8.0),
        ]),
        Layer("接口", [
            _box("api", "AdminApiClient",
                 "loginAdmin / registerAdmin / logout / createInviteCode",
                 C_SUP, 2.55, 1.35, 8.1, 1.12, 10.4, 7.9),
        ]),
    ]
    arrows = [
        Arrow("login", "api", label="账号密码"),
        Arrow("reg", "api", label="四字段"),
        Arrow("out", "api", label="token"),
        Arrow("perm", "api", label="role"),
        Arrow("api", "sess", label="token+Admin", rad=0.12),
        Arrow("sess", "out", label="清 token 回登录", rad=-0.18),
        Arrow("api", "code", label="明文 code", rad=-0.12),
        Arrow("code", "reg", label="注册消耗", rad=0.18),
    ]
    draw_architecture(
        "图 3-2-1a  账号管理与登录子模块",
        layers, arrows, out, figsize=(13.4, 8.0),
        caption="枢纽是会话数据：登录/注册写入 token，退出清掉；邀请码把发码页和注册页连在一起。",
    )


def build_admin_ops(out: str) -> None:
    layers = [
        Layer("界面", [
            _box("st", "电桩状态页", "饼图 + 占比\n关键字查明细", C_UI, 1.25, 8.55, 2.2, 1.15, 10.2, 7.6),
            _box("pm", "充电桩管理", "级联筛选\n增删改 / 重启", C_UI, 3.55, 8.55, 2.2, 1.15, 10.2, 7.6),
            _box("sm", "电站管理", "检索 + 点行\n增删改", C_UI, 5.85, 8.55, 2.15, 1.15, 10.2, 7.6),
            _box("rv", "预约管理", "active 列表\n解除预约", C_UI, 8.10, 8.55, 2.05, 1.15, 10.2, 7.6),
            _box("us", "用户管理", "手机号查询\n冻结 / 解冻", C_UI, 10.25, 8.55, 2.15, 1.15, 10.1, 7.5),
        ]),
        Layer("本地逻辑", [
            _box("kw", "关键字过滤", "编号/站名/地址\n不进请求参数", C_BIZ, 1.25, 6.70, 2.2, 1.12, 10.0, 7.5),
            _box("cas", "级联筛选", "城区 → 站点\n→ 状态", C_BIZ, 3.55, 6.70, 2.2, 1.12, 10.0, 7.5),
            _box("nf", "二次确认", "force=false 先探\nNEED_FORCE 再删", C_BIZ, 5.85, 6.70, 2.15, 1.12, 10.0, 7.5),
            _box("rst", "重启按钮", "仅选中 fault\n才显示", C_BIZ, 8.10, 6.70, 2.05, 1.12, 10.0, 7.5),
        ]),
        Layer("数据对象", [
            _box("stats", "stats", "各状态数量\n来自 dashboard(7)", C_MODEL, 1.25, 4.85, 2.2, 1.15, 10.2, 7.6),
            _box("piles", "Pile[]", "状态明细 / 管理表\n站内下表共用", C_MODEL, 3.55, 4.85, 2.2, 1.15, 10.2, 7.6),
            _box("stations", "Station[]", "筛选下拉\n与电站列表", C_MODEL, 5.85, 4.85, 2.15, 1.15, 10.2, 7.6),
            _box("rsvs", "Reservation[]", "仅 active", C_MODEL, 8.10, 4.85, 2.05, 1.15, 10.2, 7.6),
            _box("users", "User[]", "keyword 模糊", C_MODEL, 10.25, 4.85, 2.15, 1.15, 10.1, 7.5),
        ]),
        Layer("接口", [
            _box("api", "AdminApiClient",
                 "piles / stations / reservations / users / pileStats",
                 C_SUP, 1.4, 1.25, 6.35, 1.15, 10.4, 7.8),
            _box("rule", "返回码处理", "NEED_FORCE 二次确认\n充电中拒冻 · 非故障不重启",
                 C_MODEL, 8.0, 1.25, 4.4, 1.15, 10.2, 7.6),
        ]),
    ]
    arrows = [
        Arrow("st", "kw", label="关键字"),
        Arrow("st", "stats", label="pileStats"),
        Arrow("kw", "piles", label="listPiles(-1)"),
        Arrow("pm", "cas"),
        Arrow("pm", "rst", label="选中故障桩"),
        Arrow("pm", "nf", label="删除"),
        Arrow("sm", "nf", label="删站"),
        Arrow("sm", "stations", label="keyword"),
        Arrow("sm", "piles", label="stationId", rad=0.18),
        Arrow("cas", "stations", label="districts/站"),
        Arrow("cas", "piles", label="站+状态"),
        Arrow("rv", "rsvs", label="list/cancel"),
        Arrow("us", "users", label="查 / 冻结"),
        Arrow("stats", "api", bidir=True, label="dashboard"),
        Arrow("piles", "api", bidir=True, label="Pile JSON"),
        Arrow("stations", "api", bidir=True, label="Station JSON"),
        Arrow("rsvs", "api", bidir=True, label="reservationId"),
        Arrow("users", "api", bidir=True, label="userId"),
        Arrow("nf", "api", label="id+force", rad=-0.12),
        Arrow("rst", "api", label="pileId", rad=-0.18),
        Arrow("api", "rule", label="错误码", rad=0.12),
        Arrow("rsvs", "piles", label="解约→桩 idle", rad=0.22),
        Arrow("users", "rsvs", label="冻时取消1条", rad=-0.2),
        Arrow("nf", "st", label="刷新三页", rad=0.28),
    ]
    draw_architecture(
        "图 3-2-1b  运营监控子模块",
        layers, arrows, out, figsize=(13.6, 10.4),
        caption="枢纽是 Pile[] / Station[]。页面先走本地逻辑，再与接口交换数据；解约、冻结、删除会交叉改多页。",
    )


def build_admin_finance(out: str) -> None:
    layers = [
        Layer("界面", [
            _box("page", "销售业绩页", "进入 / 刷新 / 切换 7 或 30 日", C_UI, 3.55, 6.85, 6.1, 1.12, 11.0, 8.1),
        ]),
        Layer("回写控件", [
            _box("kpi", "营收 KPI", "今日 / 本月 / 总营收", C_UI, 1.4, 5.05, 3.3, 1.12, 10.6, 7.9),
            _box("chart", "营收折线", "Qt Charts 本地绘图", C_UI, 4.95, 5.05, 3.3, 1.12, 10.6, 7.9),
            _box("ord", "最近订单表", "约 12 条 · 中文状态", C_UI, 8.5, 5.05, 3.3, 1.12, 10.6, 7.9),
        ]),
        Layer("数据对象", [
            _box("payload", "dashboard payload",
                 "stats · dailySales · recentOrders   （一份 JSON，三路拆开）",
                 C_MODEL, 2.55, 3.28, 8.1, 1.12, 10.6, 8.0),
        ]),
        Layer("接口", [
            _box("api", "AdminApiClient::dashboard", "一次请求  {days:7|30}\n返回 stats / dailySales / recentOrders",
                 C_SUP, 3.35, 1.25, 6.5, 1.15, 10.4, 7.9),
        ]),
    ]
    arrows = [
        Arrow("page", "api", label="days=7|30"),
        Arrow("api", "payload", label="三块数据"),
        Arrow("payload", "kpi", label="today/month/total"),
        Arrow("payload", "chart", label="dailySales[]"),
        Arrow("payload", "ord", label="recentOrders[]"),
        Arrow("page", "kpi", rad=0.12),
        Arrow("page", "chart"),
        Arrow("page", "ord", rad=-0.12),
    ]
    draw_architecture(
        "图 3-2-1c  财务管理子模块",
        layers, arrows, out, figsize=(13.4, 9.0),
        caption="枢纽是 dashboard payload：一次拉取，扇出到 KPI / 折线 / 近单。本页不查电桩。",
    )


def build_admin_ui(out: str) -> None:
    layers = [
        Layer("界面", [
            _box("sw", "侧栏昼夜开关", "onToggleDarkMode(bool)", C_UI, 4.15, 6.85, 4.9, 1.12, 11.0, 8.1),
        ]),
        Layer("本地处理", [
            _box("theme", "applyTheme", "qApp->setStyleSheet", C_BIZ, 1.5, 5.05, 4.55, 1.12, 10.6, 8.0),
            _box("set", "QSettings", "键 ui/darkMode\n下次启动读回", C_BIZ, 7.15, 5.05, 4.55, 1.12, 10.6, 8.0),
        ]),
        Layer("实现", [
            _box("sh", "StyleHelper", "浅色 / 深色 QSS", C_MODEL, 1.5, 3.28, 4.55, 1.12, 10.6, 8.0),
            _box("ch", "图表跟主题", "再调 refreshDashboard\n与 refreshPileStatus", C_MODEL, 7.15, 3.28, 4.55, 1.12, 10.4, 7.8),
        ]),
        Layer("回写", [
            _box("app", "全窗换色", "按钮文案同步 · 折线/饼图重绘", C_UI, 3.35, 1.25, 6.5, 1.12, 10.6, 8.0),
        ]),
    ]
    arrows = [
        Arrow("sw", "theme", label="dark"),
        Arrow("sw", "set", label="记住选择"),
        Arrow("theme", "sh", label="选 QSS"),
        Arrow("theme", "ch", label="换画笔"),
        Arrow("set", "theme", label="启动还原", rad=0.2),
        Arrow("sh", "app", label="样式表"),
        Arrow("ch", "app", label="重绘 Chart"),
    ]
    draw_architecture(
        "图 3-2-1d  界面美化子模块",
        layers, arrows, out, figsize=(13.4, 9.4),
        caption="换肤不走 TCP。开关同时连 QSettings 与 applyTheme；图表为换色复用已有业绩/桩状态接口。",
    )


def build_sequences(outdir: str) -> None:
    draw_sequence(
        "图 3-1-2a  账号管理与登录",
        ["车主", "LoginDialog", "ServerApiClient", "服务端"],
        [
            (0, 1, "11 位手机号 + 密码"),
            (1, 2, "phoneLogin"),
            (2, 3, "user.phoneLogin"),
            (3, 2, "ok + token + user", "reply"),
            (2, 1, "缓存 token，返回 User", "reply"),
            (1, 0, "进入 MainWindow", "reply"),
        ],
        os.path.join(outdir, "fig_3_1_2a_user_login.png"),
        note="登录失败不自动注册。注册走独立四字段提交，成功后同样进入登录态。",
    )
    draw_sequence(
        "图 3-1-2b  找站与选桩",
        ["车主", "MainWindow", "LocationProvider", "ServerApiClient", "服务端"],
        [
            (0, 1, "打开充电站页 / 点击定位"),
            (1, 2, "requestCurrentLocation"),
            (2, 1, "经纬度（失败则北京默认点）", "reply"),
            (1, 3, "listStations(lat,lng,keyword,district)"),
            (3, 4, "stations.list"),
            (4, 3, "按距离排序的站点", "reply"),
            (0, 1, "选中站点"),
            (1, 3, "listPiles(stationId, speed, connector)"),
            (3, 4, "piles.list"),
            (4, 3, "站内电桩", "reply"),
        ],
        os.path.join(outdir, "fig_3_1_2b_user_find.png"),
        note="距离排序在拿到站点列表后于本端展示；定位失败不阻断找站。",
    )
    draw_sequence(
        "图 3-1-2c  预约与充电",
        ["车主", "MainWindow", "ServerApiClient", "服务端"],
        [
            (0, 1, "对空闲桩预约"),
            (1, 2, "createReservation(pileId)"),
            (2, 3, "reservation.create"),
            (3, 2, "锁桩 15 分钟 + 预约单", "reply"),
            (0, 1, "开始充电"),
            (1, 2, "startCharging"),
            (2, 3, "charge.start"),
            (3, 2, "订单 + 启动进度", "reply"),
            (1, 2, "updateChargingProgress（定时）"),
            (0, 1, "结束充电"),
            (1, 2, "stopCharging"),
            (2, 3, "charge.stop"),
            (3, 2, "结算后的订单", "reply"),
        ],
        os.path.join(outdir, "fig_3_1_2c_user_charge.png"),
        note="同一用户最多 3 条有效预约；同时只允许一笔进行中订单。界面负责倒计时与进度展示。",
    )
    draw_sequence(
        "图 3-1-2d  充值与订单",
        ["车主", "个人中心", "ServerApiClient", "服务端"],
        [
            (0, 1, "输入充值金额"),
            (1, 2, "rechargeUser(amount)"),
            (2, 3, "wallet.recharge"),
            (3, 2, "新余额", "reply"),
            (2, 1, "刷新余额标签", "reply"),
            (0, 1, "打开充电记录"),
            (1, 2, "listOrders"),
            (2, 3, "orders.list"),
            (3, 2, "订单列表", "reply"),
            (1, 0, "表格展示中文状态", "reply"),
        ],
        os.path.join(outdir, "fig_3_1_2d_user_pay.png"),
    )
    draw_sequence(
        "图 3-2-2a  管理员登录 / 邀请码注册",
        ["管理员", "LoginDialog", "AdminApiClient", "服务端"],
        [
            (0, 1, "输入账号密码 或 填写邀请码"),
            (1, 2, "loginAdmin / registerAdmin"),
            (2, 3, "admin.login / admin.register"),
            (3, 2, "ok + token + admin", "reply"),
            (2, 1, "缓存 token，返回 Admin", "reply"),
            (1, 0, "关闭登录窗，打开 MainWindow", "reply"),
        ],
        os.path.join(outdir, "fig_3_2_2a_admin_login.png"),
        note="注册必须消耗未使用邀请码；登录失败不建号。客户端只保存 token 与 Admin。",
    )
    draw_sequence(
        "图 3-2-2b  销售业绩刷新",
        ["管理员", "MainWindow", "AdminApiClient", "服务端"],
        [
            (0, 1, "打开销售业绩 / 刷新 / 切天数"),
            (1, 2, "dashboard(7 或 30)"),
            (2, 3, "admin.dashboard"),
            (3, 2, "stats + dailySales + recentOrders", "reply"),
            (1, 1, "拆 payload：KPI / 折线 / 近单", "self"),
            (1, 0, "更新三项控件", "reply"),
        ],
        os.path.join(outdir, "fig_3_2_2b_admin_finance.png"),
        note="一次请求覆盖三块界面。折线在客户端用 Qt Charts 绘制。",
    )
    draw_sequence(
        "图 3-2-2c  电桩/电站删除（两阶段确认）",
        ["管理员", "MainWindow", "AdminApiClient", "服务端"],
        [
            (0, 1, "选择行并确认删除"),
            (1, 2, "deletePile/Station(id, force=false)"),
            (2, 3, "admin.*.delete  {force:false}"),
            (3, 2, "占用则 code=NEED_FORCE", "reply"),
            (1, 0, "二次确认「强制删除」"),
            (0, 1, "确认强制"),
            (1, 2, "deletePile/Station(id, force=true)"),
            (2, 3, "admin.*.delete  {force:true}"),
            (3, 2, "ok", "reply"),
            (1, 0, "刷新状态/桩/站三页", "reply"),
        ],
        os.path.join(outdir, "fig_3_2_2c_admin_delete.png"),
        note="第一次探测占用，第二次才带 force。避免一次点击误删占用设备。",
    )
    draw_sequence(
        "图 3-2-2d  邀请码发放",
        ["管理员", "权限管理页", "AdminApiClient", "服务端"],
        [
            (0, 1, "选择授予角色 operator/auditor"),
            (1, 2, "createInviteCode(role)"),
            (2, 3, "admin.invites.create"),
            (3, 2, "明文 code", "reply"),
            (1, 0, "对话框展示一次性邀请码", "reply"),
        ],
        os.path.join(outdir, "fig_3_2_2d_admin_invite.png"),
        note="创建入口在权限页，消耗入口在注册页。明文只展示一次。",
    )


def main() -> int:
    parser = argparse.ArgumentParser(description="生成概要设计模块图 / 时序图")
    parser.add_argument(
        "--out",
        default="figures",
        help="输出目录（默认为本文件夹下的 figures）",
    )
    args = parser.parse_args()
    here = os.path.dirname(os.path.abspath(__file__))
    outdir = args.out if os.path.isabs(args.out) else os.path.join(here, args.out)
    os.makedirs(outdir, exist_ok=True)

    jobs = [
        ("fig_2_1_system.png", build_system),
        ("fig_3_1_user_client.png", build_user_client_overall),
        ("fig_3_1a_user_account.png", build_user_account),
        ("fig_3_1b_user_service.png", build_user_service),
        ("fig_3_1c_user_pay.png", build_user_pay),
        ("fig_3_2_admin_client.png", build_admin_overall),
        ("fig_3_2_1a_admin_account.png", build_admin_account),
        ("fig_3_2_1b_admin_ops.png", build_admin_ops),
        ("fig_3_2_1c_admin_finance.png", build_admin_finance),
        ("fig_3_2_1d_admin_ui.png", build_admin_ui),
    ]
    print(f"字体：{FONT}")
    print(f"输出：{outdir}")
    for name, fn in jobs:
        path = os.path.join(outdir, name)
        fn(path)
        print(f"  写入 {name}")
    build_sequences(outdir)
    print("  写入时序图")
    print("完成。")
    return 0


if __name__ == "__main__":
    sys.exit(main())
