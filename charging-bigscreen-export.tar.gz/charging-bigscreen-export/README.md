# 北京市充电桩运营数据可视化大屏

> **一句话介绍**：把充电桩订单、电池遥测、充电站三张原始表，用 **Spark** 完成数据清洗与 15 个维度的统计分析，
> 结果落到 **MySQL**，由 **Flask** 提供 REST 接口，前端用 **Vue3 + DataV + ECharts** 渲染成 16 个面板的可视化大屏；
> 数据同时存储在 **Hadoop 3.x（HDFS）**，作业支持提交到 **Spark on YARN**。

![大屏预览](docs/大屏预览.png)

---

## 一、项目要求对照

| 项目要求 | 本项目实现 |
| --- | --- |
| Python 3.11 或 3.12 | 清洗/分析/后端全部运行在 Python **3.12**（虚拟机实测 3.12.13） |
| 文件存储：本地测试 + 答辩放 Hadoop 3.x | 本地默认读写 `data/`、`output/`；答辩模式把原始数据与结果存入 **HDFS**（Hadoop 3.2.1） |
| 使用 Spark 做清洗与分析，分析维度 ≥ 8，至少两组对比分析 | **15 个分析维度**，其中 **5 组对比分析**（站点类型、工作日 vs 周末、峰平谷、平台、行政区） |
| 使用 Flask 处理 Web 请求并响应数据 | **23 个 REST 接口**（含大屏首屏聚合接口），30 秒内存缓存，MySQL 不可用时自动切 CSV 兜底 |
| MySQL 版本不限 | MySQL 8.0，库 `charging_screen`，**26 张表**（明细表 + 分析结果表） |
| Node.js 23 及以上，前端 Vue3 | Node.js **23.11.1** + Vue **3.5** + Vite 构建（`package.json` 声明 `"node": ">=23"`） |
| 使用 DataV 大屏展示，图表类型丰富、不单一 | DataV（边框盒/装饰/滚动榜/锥形柱/环形图/水球图）+ ECharts **16 类图表**，共 16 个面板 |

## 二、系统架构

```
 data/raw/*.csv（或 HDFS /data/charging/raw）
          │
          ▼  ① Spark 清洗   spark/jobs/etl_clean.py
   清洗宽表：session_detail / battery_detail / station_dim（parquet + csv）
          │
          ▼  ② Spark 分析   spark/jobs/analysis.py   （15 个维度、5 组对比）
   分析结果：output/ads/ads_*.csv（25 张结果表）
          │
          ▼  ③ 装载 MySQL   spark/jobs/load_mysql.py （自动建表、建索引）
        MySQL  charging_screen
          │
          ▼  ④ Flask 接口   backend/app.py （23 个 REST 接口 + 30s 缓存 + CSV 兜底）
          │
          ▼  ⑤ 可视化       frontend/  Vue3 + DataV + ECharts（60 秒自动刷新，1920×1080 等比缩放）
```

虚拟机上的完整链路（已实测跑通）：**HDFS 原始数据 → Spark on YARN 清洗与分析 → 结果写回 HDFS（parquet + csv）→ 取回本地 → 装载 MySQL → Flask 接口 → 大屏展示**。

## 三、Hadoop 使用说明（HDFS 存储 + YARN 计算）

项目**确实使用了 Hadoop 3.x**，不是只连 MySQL：

| 使用方式 | 具体做法 |
| --- | --- |
| 文件存储 | 原始数据与计算结果全部放在 HDFS：`/user/bit/charging-bigscreen/{raw,warehouse,ads}`，结果同时输出 parquet 与 csv |
| 计算引擎 | `SPARK_MASTER=yarn` 时把 Spark 清洗 + 分析作业提交到 **YARN** 运行（客户端模式，驱动在本地、执行器在 YARN 容器） |
| 结果回流 | 用 `hdfs dfs -getmerge` 把 HDFS 上的结果表取回本地，再装载 MySQL 供 Flask / 大屏查询 |
| 大屏可见 | 大屏顶部有 **「存储 HDFS (Hadoop)」「计算 Spark on YARN」** 两个标识，数据来自作业写入的 `ads_pipeline_info` 表 |

```bash
# 一键：上传原始数据到 HDFS → 提交 Spark on YARN → 结果取回 → 装载 MySQL
bash deploy/spark_submit.sh

# 分步执行（本地模式与 HDFS 模式是同一份代码，只差路径参数）
source deploy/hadoop_env.sh && export SPARK_MASTER=yarn
export PYSPARK_PYTHON=$PWD/.venv/bin/python
.venv/bin/python spark/jobs/run_all.py \
  --raw       hdfs://bitdev:9000/user/bit/charging-bigscreen/raw \
  --warehouse hdfs://bitdev:9000/user/bit/charging-bigscreen/warehouse \
  --ads       hdfs://bitdev:9000/user/bit/charging-bigscreen/ads
bash deploy/fetch_from_hdfs.sh && .venv/bin/python spark/jobs/load_mysql.py
```

验证 Hadoop 确实在工作（答辩时可现场演示）：

```bash
source deploy/hadoop_env.sh
hdfs dfs -ls /user/bit/charging-bigscreen            # raw / warehouse / ads 三个目录
hdfs dfs -du -h /user/bit/charging-bigscreen         # 各目录占用（raw 523K、warehouse 1.5M、ads 1.2M）
yarn application -list -appStates ALL | grep SPARK   # 已完成的 Spark 应用（ChargingPile-Batch，SUCCEEDED）
```

- NameNode Web UI：<http://192.168.44.129:9870>
- YARN Web UI：<http://192.168.44.129:8088>
- 已提交并成功的 YARN 应用：`application_1789135071729_0005 / 0006 / 0007`（应用名 `ChargingPile-Batch`，类型 SPARK，Final-State SUCCEEDED）

每次作业都会把「运行时间 / 计算引擎 / 存储位置 / 输入输出路径 / 记录数」写入 `ads_pipeline_info` 表，
接口 `GET /api/pipeline` 可查询，例如当前为：`Spark on YARN` + `HDFS (Hadoop)` + `3339 条有效订单`。

## 四、目录结构

```
charging-bigscreen/
├─ README.md                    本文件：项目说明与操作手册
├─ data/raw/                    原始数据（3 个 CSV，可直接替换成新数据）
│   ├─ nvv2t.csv                充电订单明细   3395 行
│   ├─ dsv13r2.csv              电池充电遥测   1594 行
│   └─ nvv2t_md_end.csv         充电站维度表   105 行
├─ spark/jobs/
│   ├─ etl_clean.py             ① 数据清洗：时间修复、去重、异常剔除、维度关联、指标派生
│   ├─ analysis.py              ② 多维分析：15 个维度 / 5 组对比，产出 ads_* 结果表
│   ├─ run_all.py               一键执行清洗 + 分析（支持 --raw/--warehouse/--ads 指定 HDFS 路径）
│   └─ load_mysql.py            ③ 结果装载 MySQL（自动推断列类型、建索引、幂等重建表）
├─ backend/                     Flask 后端
│   ├─ app.py                   全部 REST 接口 + 静态托管前端 dist
│   ├─ db.py                    连接池、TTL 缓存、CSV 兜底数据源
│   ├─ config.py                读取 config/database.env 与环境变量
│   ├─ wsgi.py                  gunicorn 入口
│   └─ requirements.txt         Flask / flask-cors / PyMySQL / gunicorn
├─ frontend/                    Vue3 + DataV 大屏
│   ├─ src/views/Screen.vue     大屏布局（16 个面板）与数据加载
│   ├─ src/charts/options.js    16 类图表的 ECharts 配置构造器
│   ├─ src/components/          HeaderBar（标题栏）、KpiBar（翻牌器/环形图/水球图）、
│   │                           PanelBox（DataV 边框面板）、EChart（图表容器）、
│   │                           RealtimeBoard（滚动榜）、CountUp（数字滚动）
│   ├─ src/api/index.js         接口封装
│   ├─ dist/                    已构建产物（Flask 直接托管，无需再装 Node 也能跑）
│   └─ package.json             依赖与构建脚本（node >= 23）
├─ config/database.env          数据库连接（后端与装载脚本共用，环境变量优先）
├─ sql/charging_screen.sql      MySQL 全库备份（26 张表，可直接还原）
├─ output/
│   ├─ warehouse/               清洗层结果（Spark 输出）
│   └─ ads/                     分析层结果 25 张 CSV（大屏数据源，可离线查看）
├─ deploy/
│   ├─ deploy.sh                一键部署：依赖 → MySQL 初始化 → Spark → 前端构建 → 启动服务
│   ├─ setup_hadoop.sh          没有 Hadoop 时一键搭伪分布式（HDFS + YARN）
│   ├─ hadoop_env.example.sh    Hadoop 环境变量模板（复制为 hadoop_env.sh 使用）
│   ├─ spark_submit.sh          HDFS + Spark on YARN 全链路（上传数据、提交作业、取回结果、装载 MySQL）
│   ├─ fetch_from_hdfs.sh       把 HDFS 上的结果表 getmerge 回本地
│   ├─ run_pipeline.sh          重跑离线计算（数据更新后刷新大屏）
│   ├─ install_service.sh       注册 systemd 服务 + nginx 反向代理（开机自启）
│   ├─ gunicorn.conf.py         gunicorn 生产配置
│   └─ systemd/、nginx/         服务与反向代理配置模板
├─ docs/
│   ├─ 大屏预览.png             实际运行截图
│   ├─ 答辩要点.md              清洗发现、维度设计、可直接口述的结论
│   ├─ 答辩演示流程.md          10 分钟演示脚本 + 常见提问应答
│   └─ 虚拟机部署记录.md        虚拟机实际部署状态、命令与踩坑记录
├─ start_backend.bat            Windows 本地启动后端
└─ run_pipeline.bat             Windows 本地一键跑离线计算
```

## 五、环境要求

| 组件 | 版本要求 | 说明 |
| --- | --- | --- |
| Python | 3.11 / 3.12 | 虚拟环境解释器 |
| PySpark | 3.5.3 | 清洗与分析作业 |
| Java | 11（或 8u371+/17） | Spark 运行需要；Hadoop 自身可用 Java 8 |
| MySQL | 5.7 / 8.x | 存清洗明细与分析结果 |
| Node.js | **23 及以上** | 仅前端构建需要，运行大屏不需要 |
| Hadoop（可选） | 3.x | 答辩模式用于 HDFS 存储与 YARN 计算 |

## 六、快速开始

### 6.1 Windows 本地运行（3 步）

```bat
:: 第 1 步：安装后端与 Spark 依赖
python -m venv .venv
.venv\Scripts\pip install -r backend\requirements.txt
.venv\Scripts\pip install pyspark==3.5.3 pandas

:: 第 2 步：配置好 MySQL 后执行离线计算（清洗 → 分析 → 装载 MySQL）
::         连接信息写在 config\database.env
run_pipeline.bat

:: 第 3 步：构建前端并启动服务
cd frontend && npm install && npm run build && cd ..
start_backend.bat
```

浏览器打开 <http://127.0.0.1:5000/> 即可看到大屏（`frontend/dist` 已随项目提供，可跳过 npm 构建）。

### 6.2 Linux 虚拟机 / 服务器一键部署

```bash
cd charging-bigscreen
bash deploy/deploy.sh           # 安装依赖 + 初始化 MySQL + 跑 Spark + 构建前端 + 启动服务
bash deploy/install_service.sh  # 可选：注册 systemd 开机自启 + nginx 80 端口反向代理
```

脚本特点：自动识别 `apt/yum/dnf`；Ubuntu 上 root 走 `auth_socket` 时自动创建应用账号；
Python 优先 3.12，其次 3.11/3.10；Node 23 通过 nodesource 安装；可重复执行（幂等）。

### 6.3 答辩模式：HDFS + Spark on YARN

```bash
# 1) 机器上还没有 Hadoop 时，一键搭伪分布式（HDFS + YARN）
bash deploy/setup_hadoop.sh

# 2) 生成 Hadoop 环境变量文件（按实际安装路径修改，模板在 deploy/hadoop_env.example.sh）
cp deploy/hadoop_env.example.sh deploy/hadoop_env.sh

# 3) 上传原始数据到 HDFS → 提交 Spark on YARN → 结果取回 → 装载 MySQL
bash deploy/spark_submit.sh

# 也可以分步执行（本地与 HDFS 是同一份代码，只差路径参数）
source deploy/hadoop_env.sh && export SPARK_MASTER=yarn
export PYSPARK_PYTHON=$PWD/.venv/bin/python
.venv/bin/python spark/jobs/run_all.py \
  --raw       hdfs://<NameNode>:9000/user/bit/charging-bigscreen/raw \
  --warehouse hdfs://<NameNode>:9000/user/bit/charging-bigscreen/warehouse \
  --ads       hdfs://<NameNode>:9000/user/bit/charging-bigscreen/ads
bash deploy/fetch_from_hdfs.sh && .venv/bin/python spark/jobs/load_mysql.py
```

## 七、数据说明

| 文件 | 含义 | 行数 | 关键字段 |
| --- | --- | --- | --- |
| `nvv2t.csv` | 充电订单明细 | 3395 | sessionId、kwhTotal、charging_fees、created/ended、chargeTimeHrs、weekday、platform、userId、stationId、facilityType、Mon~Sun |
| `dsv13r2.csv` | 电池充电遥测 | 1594 | esd(会话号)、soc、pack_voltage、charge_current、单体最高/最低电压、最高/最低温度、可用能量/容量、record_time |
| `nvv2t_md_end.csv` | 充电站维度 | 105 | stationId、locationId、facilityType、station_name、address、device_count、open_time |

原始数据存在三类质量问题，也是清洗的重点：

1. **订单时间年份被抹掉高两位**：`0014-11-18 15:40:26` 实际是 2014-11-18；
2. **存在异常订单**：0 电量订单、55.2 小时的超长时长记录；
3. **遥测 `record_time` 全为科学计数法 `2.02E+13`**，有效数字丢失、无法还原真实时间。

## 八、数据清洗规则（`spark/jobs/etl_clean.py`）

| # | 规则 | 结果 |
| --- | --- | --- |
| 1 | 年份修复：缺失的高两位统一 +2000 后解析为标准 timestamp | 用 `Mon~Sun` 独热列交叉验证，**3395/3395 条星期完全一致**，证明修正正确 |
| 2 | 业务主键去重（`sessionId`）+ 关键字段空值校验 | 无重复、无空值 |
| 3 | 异常订单剔除：电量 ≤0（55 条）或 >40kWh、时长 ≤0 或 >12h、金额为负 | 共剔除 **56 条**，有效订单 **3339 条** |
| 4 | 遥测字段规范化：电流为负值（充电方向约定）统一取幅值 | `charge_current` 全部为正 |
| 5 | 无效字段丢弃：`record_time` 精度丢失且无法复原 | 丢弃该字段并在质量报告中说明 |
| 6 | 派生指标：平均功率、单价、峰平谷时段、是否周末、单体压差、温升、SOC 分箱 | 供后续多维分析使用 |
| 7 | 维度关联与解析：订单关联站点维度，从站名解析行政区/道路/站点类型 | 站名关键字与 `facilityType` 编码 105/105 一致（1=交流、2=直流、3=交直流、4=超充） |

清洗各阶段的记录数落到 `ads_data_quality` 表，大屏顶部实时展示「原始 3395 → 有效 3339」。

## 九、分析维度（15 个，含 5 组对比分析）

| # | 分析维度 | 结果表 | 大屏面板 |
| --- | --- | --- | --- |
| 1 | 运营总览 KPI | `ads_overview` | 顶部 9 项翻牌器 + 环形图 + 水球图 |
| 2 | 日充电量/订单趋势 | `ads_daily_trend` | 日充电量与订单趋势（双轴） |
| 3 | 月度充电量趋势 | `ads_monthly_trend` | 月度趋势（柱 + 折线） |
| 4 | 24 小时充电负荷 | `ads_hour_load` | 24 小时负荷（峰/平/谷着色 + 峰值标注） |
| 5 | 星期 × 小时充电热度 | `ads_weekday_hour_heat` | 热力图 |
| 6 | 站点充电量 TOP10 | `ads_station_top` / `ads_station_all` | 站点排行（横向条形） |
| 7 | **行政区分布（对比）** | `ads_district` | 行政区锥形柱图 |
| 8 | **站点类型对比** | `ads_facility_compare` | 雷达图 |
| 9 | **工作日 vs 周末对比** | `ads_weekend_compare` | 分组柱状 + 折线 |
| 10 | **峰平谷时段对比** | `ads_time_period` | 漏斗图 |
| 11 | 用户价值分层（RFM） | `ads_user_value` / `ads_user_segment` | 环形占比图 |
| 12 | 充电时长分布 | `ads_duration_dist` | 玫瑰图 |
| 13 | 单次充电量分布 | `ads_energy_dist` | 柱状 + 占比折线 |
| 14 | 充电功率分布 / 电池健康 | `ads_power_dist` / `ads_battery_health` / `ads_battery_type_compare` | 电池健康画像（柱 + 双折线） |
| 15 | **收入结构与平台对比** | `ads_revenue_struct` / `ads_platform_compare` | 收入结构柱状 + 付费率折线、平台对比 |

### 主要分析结论

- 统计区间 **2014-11-18 ~ 2015-10-04**：有效订单 3339 单、充电量 19719.59 kWh、充电站 105 座、
  充电桩 562 台、活跃用户 84 人、累计收入 398.02 元、付费订单占比 11.29%。
- **用户二八分布**：高价值用户 30 人（35.7%）贡献 **80.4%** 的充电量；流失风险用户 15 人仅贡献 1.2%。
- **站点类型**：交直流站订单占比 53.9%、电量占比 54.3%；超充站单次电量最高（7.31 kWh）、付费率最高（38.68%）；交流站付费率最低（3.57%）。
- **工作日 vs 周末**：工作日日均 16.6 单 / 97.66 kWh；周末日均 2.13 单 / 14.45 kWh（周末样本仅 40 天，结论需结合样本量看）。
- **时段特征**：平段订单 57.95%、峰段 41.54%、谷段仅 0.51%，夜间谷电利用率低，存在错峰引导空间。
- **电池健康**：SOC 20%→80% 时单体压差由 13.4mV 升至 29.0mV、最高温度由 33.3℃ 升至 37.0℃，高 SOC 区间一致性变差。
- **区域分布**：经开区、二七区、航空港区合计贡献 57.9% 电量；航空港区桩均订单最高（6.94 单/台）。

## 十、大屏说明

- 设计分辨率 **1920×1080**，按浏览器窗口等比缩放，适配任意分辨率；数据 **60 秒自动刷新**，后端结果缓存 30 秒。
- 首屏只发一个聚合请求 `GET /api/screen/bundle`，一次返回 19 个数据集，减少并发与等待。
- 16 个面板使用的图表类型：翻牌数字、环形占比、水球图、柱状、折线、面积、双轴混合、雷达、
  热力图、玫瑰图、漏斗图、锥形柱图、横向条形、分组柱状、堆叠柱 + 折线、滚动榜。

## 十一、后端接口

| 接口 | 说明 |
| --- | --- |
| `GET /api/health` | 服务与数据库状态（`data_source` 显示当前是 mysql 还是 csv） |
| `GET /api/screen/bundle` | 大屏首屏聚合数据（19 个数据集，30s 缓存） |
| `GET /api/overview` | 运营总览 KPI |
| `GET /api/trend/daily?days=90`、`GET /api/trend/monthly` | 日趋势、月趋势 |
| `GET /api/hour-load`、`GET /api/heat/weekday-hour` | 24 小时负荷、星期×小时热度 |
| `GET /api/stations/top?limit=10`、`GET /api/districts` | 站点排行、行政区分布 |
| `GET /api/facility/compare`、`GET /api/weekend/compare`、`GET /api/time-period`、`GET /api/platform/compare` | 4 组对比分析接口 |
| `GET /api/users/segments`、`GET /api/users/top` | 用户分层占比、用户价值榜 |
| `GET /api/dist/duration`、`/energy`、`/power` | 时长、电量、功率分布 |
| `GET /api/battery/health`、`GET /api/battery/type-compare` | 电池健康、按站型的电池参数对比 |
| `GET /api/revenue/struct?dim=站点类型` | 收入结构与付费率（维度可切换） |
| `GET /api/quality`、`GET /api/realtime?limit=20` | 清洗质量报告、实时订单流水 |
| `GET /api/pipeline` | 本次作业的数据链路信息（计算引擎 Spark on YARN / 存储 HDFS） |
| `POST /api/cache/refresh` | 清空后端缓存（数据更新后可立即生效） |

数据源模式由 `config/database.env` 的 `DATA_SOURCE` 控制：`mysql`（默认）或 `csv`（MySQL 不可用时直接读 `output/ads/*.csv`）。

## 十二、数据库说明

- 库名：`charging_screen`；应用账号：`charging / charging123`（`deploy.sh` 部署时自动创建，也可自行修改 `config/database.env`）。
- 共 **26 张表**：3 张明细/维度表（`session_detail` 3339 行、`battery_detail` 1594 行、`station_dim` 105 行）
  + 22 张分析结果表（`ads_*`）+ 作业日志表 `etl_job_log`。
- 备份文件 `sql/charging_screen.sql` 可直接还原：

```bash
mysql -uroot -p < sql/charging_screen.sql     # 还原整个库（含建表与数据）
```

## 十三、部署记录（虚拟机实际状态）

| 项目 | 状态 |
| --- | --- |
| 大屏地址 | <http://192.168.44.129/>（nginx 80 端口）、<http://192.168.44.129:5000/>（Flask 直连） |
| 后端服务 | systemd 服务 `charging-screen`（gunicorn + Flask），已设置开机自启，运行用户 `bit` |
| 运行环境 | Ubuntu 22.04、MySQL 8.0、Python 3.12.13（项目内 `.venv`）、PySpark 3.5.3、Node v23.11.1 |
| Hadoop | 复用 Hadoop 3.2.1（`/opt/module/hadoop-3.2.1`），HDFS 与 YARN 均 RUNNING |
| HDFS 数据 | `/user/bit/charging-bigscreen/{raw,warehouse,ads}` |
| 项目目录 | `/home/bit/charging-bigscreen` |

常用运维命令：

```bash
sudo systemctl status charging-screen      # 查看后端状态
sudo systemctl restart charging-screen     # 重启后端
sudo nginx -s reload                       # 重载 nginx
tail -f logs/gunicorn.log                  # 后端日志
bash deploy/run_pipeline.sh                # 数据更新后重跑计算
```

### 三个已解决的部署坑（换机器时注意）

1. **HDFS 地址必须用 `bitdev:9000`，不能用 `localhost:9000`**：该虚拟机 `127.0.0.1:9000` 被另一个服务（`admin_server`）占用，
   连 `localhost:9000` 会报 `EOFException`，容易被误判成 Hadoop 版本不兼容。
2. **Spark 用 Java 11，Hadoop 用 Java 8**：Spark 3.5 要求 Java 8u371+/11/17，而机器自带 JDK 1.8.0_261 跑 Hadoop，
   因此额外安装 `openjdk-11-jdk-headless` 给 Spark 使用（在 `deploy/hadoop_env.sh` 中指定）。
3. **nginx 采用全量反向代理**：Ubuntu 家目录默认权限 750，nginx(www-data) 读不到 `frontend/dist`，
   因此由 Flask 托管静态文件、nginx 统一反代到 `127.0.0.1:5000`。

## 十四、常见问题（FAQ）

| 现象 | 处理方式 |
| --- | --- |
| 大屏无数据 / 接口 500 | 先看 `GET /api/health`：`data_source` 是 `csv` 说明 MySQL 没连上，检查 `config/database.env` 并确认已执行 `load_mysql.py` |
| Spark 报 `HADOOP_HOME ... unset` | Linux 安装 JDK 并设置 `JAVA_HOME`；Windows 本地出现该告警正常（会自动回退为驱动端写出，结果一致） |
| `pip install pyspark` 太慢或超时 | 换国内镜像：`pip install -i https://mirrors.aliyun.com/pypi/simple pyspark==3.5.3`（实测阿里云最快） |
| `npm install` 慢 | `frontend/.npmrc` 已配置 `registry.npmmirror.com`，也可换成内网源 |
| 数据更新后大屏没变 | 执行 `bash deploy/run_pipeline.sh`，或 `curl -X POST http://127.0.0.1:5000/api/cache/refresh` |
| 想换城市名称 | 只改 `frontend/src/components/HeaderBar.vue` 与 `frontend/index.html` 的标题，然后 `npm run build`；原始数据保持不动 |

## 十五、文档索引

- [docs/答辩要点.md](docs/答辩要点.md)：清洗发现、维度设计、可直接口述的结论数据
- [docs/答辩演示流程.md](docs/答辩演示流程.md)：10 分钟演示脚本与常见提问应答
- [docs/虚拟机部署记录.md](docs/虚拟机部署记录.md)：虚拟机部署状态、命令与踩坑
- [docs/大屏预览.png](docs/大屏预览.png)：大屏实际运行截图
